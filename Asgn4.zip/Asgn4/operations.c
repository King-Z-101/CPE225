int addnums(int first_num, int second_num){
    return first_num + second_num;
}

int subnums(int first_num, int second_num){
    return first_num - second_num;
}

int multnums(int first_num, int second_num){
    return first_num * second_num;
}

int divnums(int first_num, int second_num){
    return first_num / second_num;
}

int andnums(int first_num, int second_num){
    return first_num & second_num;
}

int ornums(int first_num, int second_num){
    return first_num | second_num;
}

int xornums(int first_num, int second_num){
    return first_num ^ second_num;
}

int lshiftnums(int first_num, int second_num){
    return first_num << second_num;
}

unsigned int rshiftnums(unsigned int first_num, int second_num){
    return first_num >> second_num;
}